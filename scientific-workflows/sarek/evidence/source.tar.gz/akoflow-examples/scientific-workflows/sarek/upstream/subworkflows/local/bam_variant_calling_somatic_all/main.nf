//
// PAIRED VARIANT CALLING
//

include { BAM_VARIANT_CALLING_CNVKIT                          } from '../bam_variant_calling_cnvkit'
include { BAM_VARIANT_CALLING_FREEBAYES                       } from '../bam_variant_calling_freebayes'
include { BAM_VARIANT_CALLING_INDEXCOV                        } from '../bam_variant_calling_indexcov'
include { BAM_VARIANT_CALLING_MPILEUP as MPILEUP_NORMAL       } from '../bam_variant_calling_mpileup'
include { BAM_VARIANT_CALLING_MPILEUP as MPILEUP_TUMOR        } from '../bam_variant_calling_mpileup'
include { BAM_VARIANT_CALLING_SOMATIC_ASCAT                   } from '../bam_variant_calling_somatic_ascat'
include { BAM_VARIANT_CALLING_SOMATIC_CONTROLFREEC            } from '../bam_variant_calling_somatic_controlfreec'
include { BAM_VARIANT_CALLING_SOMATIC_DEEPSOMATIC             } from '../bam_variant_calling_somatic_deepsomatic'
include { BAM_VARIANT_CALLING_SOMATIC_MANTA                   } from '../bam_variant_calling_somatic_manta'
include { BAM_VARIANT_CALLING_SOMATIC_MUSE                    } from '../bam_variant_calling_somatic_muse'
include { BAM_VARIANT_CALLING_MUTECT2                         } from '../bam_variant_calling_mutect2'
include { BAM_VARIANT_CALLING_SOMATIC_PARABRICKS_DEEPSOMATIC  } from '../bam_variant_calling_somatic_parabricks_deepsomatic'
include { BAM_VARIANT_CALLING_PARABRICKS_MUTECTCALLER         } from '../bam_variant_calling_parabricks_mutectcaller'
include { BAM_VARIANT_CALLING_SOMATIC_STRELKA                 } from '../bam_variant_calling_somatic_strelka'
include { BAM_VARIANT_CALLING_SOMATIC_TIDDIT                  } from '../bam_variant_calling_somatic_tiddit'
include { BAM_VARIANT_CALLING_SOMATIC_TNSCOPE                 } from '../bam_variant_calling_somatic_tnscope'
include { MSISENSORPRO_MSISOMATIC                             } from '../../../modules/nf-core/msisensorpro/msisomatic'

workflow BAM_VARIANT_CALLING_SOMATIC_ALL {
    take:
    tools                         // Mandatory, list of tools to apply
    bam                           // channel: [mandatory] bam
    cram                          // channel: [mandatory] cram
    bwa                           // channel: [optional] bwa
    cf_chrom_len                  // channel: [optional] controlfreec length file
    chr_files
    dbsnp                         // channel: [mandatory] dbsnp
    dbsnp_tbi                     // channel: [mandatory] dbsnp_tbi
    dict                          // channel: [mandatory] dict
    fasta                         // channel: [mandatory] fasta
    fasta_fai                     // channel: [mandatory] fasta_fai
    force_call_alleles            // channel: [optional]  force_call_alleles
    force_call_alleles_tbi        // channel: [optional]  force_call_alleles_tbi
    germline_resource             // channel: [optional]  germline_resource
    germline_resource_tbi         // channel: [optional]  germline_resource_tbi
    contamination_resource        // channel: [optional]  contamination_resource
    contamination_resource_tbi    // channel: [optional]  contamination_resource_tbi
    intervals                     // channel: [mandatory] [ intervals, num_intervals ] or [ [], 0 ] if no intervals
    intervals_bed_gz_tbi          // channel: [mandatory] intervals/target regions index zipped and indexed
    intervals_bed_combined        // channel: [mandatory] intervals/target regions in one file unzipped
    intervals_bed_gz_tbi_combined // channel: [mandatory] intervals/target regions in one file zipped
    mappability
    msisensorpro_scan               // channel: [optional]  msisensorpro_scan
    panel_of_normals                // channel: [optional]  panel_of_normals
    panel_of_normals_tbi            // channel: [optional]  panel_of_normals_tbi
    allele_files                    // channel: [optional]  ascat allele files
    loci_files                      // channel: [optional]  ascat loci files
    gc_file                         // channel: [optional]  ascat gc content file
    rt_file                         // channel: [optional]  ascat rt file
    joint_mutect2                   // boolean: [mandatory] [default: false] run mutect2 in joint mode
    wes                             // boolean: [mandatory] [default: false] whether targeted data is processed
    contamination_resource_provided // boolean: [mandatory] whether a contamination resource was provided

    main:
    // channels are often remapped to match module/subworkflow

    //TODO: Temporary until the if's can be removed and printing to terminal is prevented with "when" in the modules.config
    out_indexcov     = channel.empty()
    out_msisensorpro = channel.empty()
    vcf_freebayes    = channel.empty()
    vcf_manta        = channel.empty()
    vcf_muse         = channel.empty()
    vcf_mutect2      = channel.empty()
    vcf_strelka      = channel.empty()
    vcf_tiddit       = channel.empty()
    vcf_tnscope      = channel.empty()
    tbi_freebayes    = channel.empty()
    tbi_manta        = channel.empty()
    tbi_muse         = channel.empty()
    tbi_mutect2      = channel.empty()
    tbi_strelka      = channel.empty()
    tbi_tiddit       = channel.empty()
    tbi_tnscope      = channel.empty()

    if (tools && tools.split(',').contains('ascat')) {
        BAM_VARIANT_CALLING_SOMATIC_ASCAT(
            cram,
            allele_files,
            loci_files,
            (wes ? intervals_bed_combined : []),
            fasta.map { _meta, fasta_ -> [fasta_] },
            gc_file,
            rt_file,
        )

    }

    // CONTROLFREEC
    if (tools && tools.split(',').contains('controlfreec')) {
        cram_normal = cram.map { meta, normal_cram, normal_crai, _tumor_cram, _tumor_crai -> [meta, normal_cram, normal_crai] }
        cram_tumor = cram.map { meta, _normal_cram, _normal_crai, tumor_cram, tumor_crai -> [meta, tumor_cram, tumor_crai] }

        MPILEUP_NORMAL(
            cram_normal,
            dict,
            fasta,
            fasta_fai,
            intervals,
        )

        MPILEUP_TUMOR(
            cram_tumor,
            dict,
            fasta,
            fasta_fai,
            intervals,
        )

        mpileup_normal = MPILEUP_NORMAL.out.mpileup
        mpileup_tumor = MPILEUP_TUMOR.out.mpileup
        mpileup_pair = mpileup_normal.cross(mpileup_tumor).map { normal, tumor -> [normal[0], normal[1], tumor[1], [], [], [], []] }

        BAM_VARIANT_CALLING_SOMATIC_CONTROLFREEC(
            mpileup_pair,
            fasta.map { _meta, fasta_ -> [fasta_] },
            cf_chrom_len ?: fasta_fai.map { _meta, fasta_fai_ -> [fasta_fai_] },
            dbsnp,
            dbsnp_tbi,
            chr_files,
            mappability,
            wes ? intervals_bed_combined : [],
        )

    }

    // CNVKIT
    if (tools && tools.split(',').contains('cnvkit')) {
        BAM_VARIANT_CALLING_CNVKIT(
            bam.map { meta, normal_bam, _normal_bai, tumor_bam, _tumor_bai -> [meta, tumor_bam, normal_bam] },
            fasta,
            fasta_fai,
            intervals_bed_combined.map { _intervals -> _intervals ? [[id: _intervals[0].baseName], _intervals] : [[id: 'no_intervals'], []] },
            [[id: "null"], []],
        )
    }

    // FREEBAYES
    if (tools && tools.split(',').contains('freebayes')) {
        BAM_VARIANT_CALLING_FREEBAYES(
            cram,
            dict,
            fasta,
            fasta_fai,
            intervals,
        )

        vcf_freebayes = BAM_VARIANT_CALLING_FREEBAYES.out.vcf
        tbi_freebayes = BAM_VARIANT_CALLING_FREEBAYES.out.tbi
    }

    // DEEPSOMATIC
    cram_deepsomatic = cram.filter { _meta, _normal_cram, _normal_crai, _tumor_cram, _tumor_crai ->
        tools && tools.split(',').contains('deepsomatic')
    }

    BAM_VARIANT_CALLING_SOMATIC_DEEPSOMATIC(
        cram_deepsomatic,
        dict,
        fasta,
        fasta_fai,
        intervals,
    )

    vcf_deepsomatic = BAM_VARIANT_CALLING_SOMATIC_DEEPSOMATIC.out.vcf
    tbi_deepsomatic = BAM_VARIANT_CALLING_SOMATIC_DEEPSOMATIC.out.tbi

    // MANTA
    if (tools && tools.split(',').contains('manta')) {
        BAM_VARIANT_CALLING_SOMATIC_MANTA(
            cram,
            fasta,
            fasta_fai,
            intervals_bed_gz_tbi_combined,
        )

        vcf_manta = BAM_VARIANT_CALLING_SOMATIC_MANTA.out.diploid_sv_vcf.mix(BAM_VARIANT_CALLING_SOMATIC_MANTA.out.somatic_sv_vcf)
        tbi_manta = BAM_VARIANT_CALLING_SOMATIC_MANTA.out.diploid_sv_vcf_tbi.mix(BAM_VARIANT_CALLING_SOMATIC_MANTA.out.somatic_sv_vcf_tbi)
    }

    // INDEXCOV
    //   WGS only
    if (wes == false && tools.split(',').contains('indexcov')) {
        BAM_VARIANT_CALLING_INDEXCOV(
            cram,
            fasta,
            fasta_fai,
        )

        out_indexcov = BAM_VARIANT_CALLING_INDEXCOV.out.out_indexcov
    }

    // STRELKA
    if (tools && tools.split(',').contains('strelka')) {
        cram_strelka = tools.split(',').contains('manta')
            // Manta's candidate small indels feed Strelka; strip the manta variantcaller tag so the meta matches cram for the join
            ? cram.join(BAM_VARIANT_CALLING_SOMATIC_MANTA.out.candidate_small_indels_vcf.map { meta, vcf -> [meta - meta.subMap('variantcaller'), vcf] }, failOnDuplicate: true, failOnMismatch: true).join(BAM_VARIANT_CALLING_SOMATIC_MANTA.out.candidate_small_indels_vcf_tbi.map { meta, tbi -> [meta - meta.subMap('variantcaller'), tbi] }, failOnDuplicate: true, failOnMismatch: true)
            : cram.map { meta, normal_cram, normal_crai, tumor_cram, tumor_crai -> [meta, normal_cram, normal_crai, tumor_cram, tumor_crai, [], []] }

        BAM_VARIANT_CALLING_SOMATIC_STRELKA(
            cram_strelka,
            dict,
            fasta.map { _meta, fasta_ -> [fasta_] },
            fasta_fai.map { _meta, fasta_fai_ -> [fasta_fai_] },
            intervals_bed_gz_tbi,
        )

        vcf_strelka = BAM_VARIANT_CALLING_SOMATIC_STRELKA.out.vcf
        tbi_strelka = BAM_VARIANT_CALLING_SOMATIC_STRELKA.out.tbi
    }

    // MSISENSORPRO
    if (tools && tools.split(',').contains('msisensorpro')) {
        MSISENSORPRO_MSISOMATIC(cram.combine(intervals_bed_combined), fasta, msisensorpro_scan)

        out_msisensorpro = out_msisensorpro.mix(MSISENSORPRO_MSISOMATIC.out.output_report)
    }

    // MuSE
    if (tools && tools.split(',').contains('muse')) {
        BAM_VARIANT_CALLING_SOMATIC_MUSE(
            bam.map { meta, normal_bam, normal_bai, _tumor_bam, _tumor_bai -> [meta, normal_bam, normal_bai] },
            bam.map { meta, _normal_bam, _normal_bai, tumor_bam, tumor_bai -> [meta, tumor_bam, tumor_bai] },
            fasta,
            dbsnp,
            dbsnp_tbi,
        )

        vcf_muse = BAM_VARIANT_CALLING_SOMATIC_MUSE.out.vcf
        tbi_muse = BAM_VARIANT_CALLING_SOMATIC_MUSE.out.tbi
    }

    // MUTECT2
    if (tools && tools.split(',').contains('mutect2')) {
        BAM_VARIANT_CALLING_MUTECT2(
            cram,
            fasta,
            fasta_fai,
            dict,
            force_call_alleles,
            force_call_alleles_tbi,
            germline_resource,
            germline_resource_tbi,
            contamination_resource,
            contamination_resource_tbi,
            panel_of_normals,
            panel_of_normals_tbi,
            intervals,
            joint_mutect2,
            contamination_resource_provided,
        )

        vcf_mutect2 = BAM_VARIANT_CALLING_MUTECT2.out.vcf
        tbi_mutect2 = BAM_VARIANT_CALLING_MUTECT2.out.tbi
    }

    // PARABRICKS DEEPSOMATIC
    cram_parabricks_deepsomatic = cram.filter { _meta, _normal_cram, _normal_crai, _tumor_cram, _tumor_crai ->
        tools && tools.split(',').contains('parabricks_deepsomatic')
    }

    BAM_VARIANT_CALLING_SOMATIC_PARABRICKS_DEEPSOMATIC(
        cram_parabricks_deepsomatic,
        fasta,
        intervals_bed_combined,
    )

    vcf_parabricks_deepsomatic = BAM_VARIANT_CALLING_SOMATIC_PARABRICKS_DEEPSOMATIC.out.vcf
    tbi_parabricks_deepsomatic = BAM_VARIANT_CALLING_SOMATIC_PARABRICKS_DEEPSOMATIC.out.tbi

    // PARABRICKS MUTECTCALLER
    cram_parabricks_mutectcaller = cram.filter { _meta, _normal_cram, _normal_crai, _tumor_cram, _tumor_crai ->
        tools && tools.split(',').contains('parabricks_mutectcaller')
    }

    BAM_VARIANT_CALLING_PARABRICKS_MUTECTCALLER(
        cram_parabricks_mutectcaller,
        fasta,
        fasta_fai,
        dict,
        force_call_alleles,
        force_call_alleles_tbi,
        germline_resource,
        germline_resource_tbi,
        contamination_resource,
        contamination_resource_tbi,
        panel_of_normals,
        panel_of_normals_tbi,
        intervals_bed_combined,
        intervals,
        contamination_resource_provided,
    )

    vcf_parabricks_mutectcaller = BAM_VARIANT_CALLING_PARABRICKS_MUTECTCALLER.out.vcf
    tbi_parabricks_mutectcaller = BAM_VARIANT_CALLING_PARABRICKS_MUTECTCALLER.out.tbi

    // TNSCOPE
    if (tools && tools.split(',').contains('sentieon_tnscope')) {

        BAM_VARIANT_CALLING_SOMATIC_TNSCOPE(
            cram.map { meta, normal_cram, normal_crai, tumor_cram, tumor_crai ->
                [meta, [normal_cram, tumor_cram], [normal_crai, tumor_crai]]
            },
            fasta,
            fasta_fai,
            dict,
            germline_resource,
            germline_resource_tbi,
            panel_of_normals,
            panel_of_normals_tbi,
            intervals,
        )

        vcf_tnscope = BAM_VARIANT_CALLING_SOMATIC_TNSCOPE.out.vcf
        tbi_tnscope = BAM_VARIANT_CALLING_SOMATIC_TNSCOPE.out.index
    }

    // TIDDIT
    if (tools && tools.split(',').contains('tiddit')) {
        BAM_VARIANT_CALLING_SOMATIC_TIDDIT(
            cram.map { meta, normal_cram, normal_crai, _tumor_cram, _tumor_crai -> [meta, normal_cram, normal_crai] },
            cram.map { meta, _normal_cram, _normal_crai, tumor_cram, tumor_crai -> [meta, tumor_cram, tumor_crai] },
            fasta,
            fasta_fai,
            bwa,
        )

        vcf_tiddit = BAM_VARIANT_CALLING_SOMATIC_TIDDIT.out.vcf
        tbi_tiddit = BAM_VARIANT_CALLING_SOMATIC_TIDDIT.out.tbi
    }

    vcf_all = channel.empty()
        .mix(
            vcf_freebayes,
            vcf_deepsomatic,
            vcf_manta,
            vcf_muse,
            vcf_mutect2,
            vcf_parabricks_deepsomatic,
            vcf_parabricks_mutectcaller,
            vcf_strelka,
            vcf_tiddit,
            vcf_tnscope,
        )

    tbi_all = channel.empty()
        .mix(
            tbi_freebayes,
            tbi_deepsomatic,
            tbi_manta,
            tbi_muse,
            tbi_mutect2,
            tbi_parabricks_deepsomatic,
            tbi_parabricks_mutectcaller,
            tbi_strelka,
            tbi_tiddit,
            tbi_tnscope,
        )

    emit:
    out_indexcov
    out_msisensorpro
    vcf_all
    vcf_freebayes
    vcf_deepsomatic
    vcf_manta
    vcf_muse
    vcf_mutect2
    vcf_parabricks_deepsomatic
    vcf_parabricks_mutectcaller
    vcf_strelka
    vcf_tiddit
    vcf_tnscope
    tbi_all
    tbi_freebayes
    tbi_deepsomatic
    tbi_manta
    tbi_muse
    tbi_mutect2
    tbi_parabricks_deepsomatic
    tbi_parabricks_mutectcaller
    tbi_strelka
    tbi_tiddit
    tbi_tnscope
}
