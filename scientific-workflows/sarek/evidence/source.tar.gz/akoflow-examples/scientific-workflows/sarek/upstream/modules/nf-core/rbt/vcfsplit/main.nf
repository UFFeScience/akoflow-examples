process RBT_VCFSPLIT {
    tag "${meta.id}"
    label 'process_single'

    conda "${moduleDir}/environment.yml"
    container "${workflow.containerEngine in ['singularity', 'apptainer'] && !task.ext.singularity_pull_docker_container
        ? 'https://depot.galaxyproject.org/singularity/rust-bio-tools:0.42.2--h4458251_1'
        : 'quay.io/biocontainers/rust-bio-tools:0.42.2--h4458251_1'}"

    input:
    tuple val(meta), path(vcf)
    val numchunks

    output:
    tuple val(meta), path("*.bcf"), emit: bcfchunks
    tuple val("${task.process}"), val('rbt'), eval("rbt --version | grep -oE '[0-9]+(\\.[0-9]+)+' | head -n 1"), topic: versions, emit: versions_rbt

    when:
    task.ext.when == null || task.ext.when

    script:
    // No args because tool does not accept args, only stdin/stdout
    def prefix = task.ext.prefix ?: "${meta.id}"
    def chunks = numchunks ? (numchunks - 1) : 15
    """
    rbt vcf-split \\
        ${vcf} \\
        ${prefix}.{0..${chunks}}.bcf
    """

    stub:
    def prefix = task.ext.prefix ?: "${meta.id}"
    def chunks = numchunks ? (numchunks - 1) : 15
    def bcf_files = (0..chunks).collect { items -> "${prefix}.${items}.bcf" }.join(' ')
    """
    touch ${bcf_files}
    """
}
