// Subworkflow with functionality specific to the nf-core/sarek pipeline

/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    IMPORT FUNCTIONS / MODULES / SUBWORKFLOWS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

include { UTILS_NFSCHEMA_PLUGIN   } from '../../nf-core/utils_nfschema_plugin'
include { paramsSummaryMap        } from 'plugin/nf-schema'
include { samplesheetToList       } from 'plugin/nf-schema'
include { paramsHelp              } from 'plugin/nf-schema'
include { completionEmail         } from '../../nf-core/utils_nfcore_pipeline'
include { completionSummary       } from '../../nf-core/utils_nfcore_pipeline'
include { UTILS_NFCORE_PIPELINE   } from '../../nf-core/utils_nfcore_pipeline'
include { UTILS_NEXTFLOW_PIPELINE } from '../../nf-core/utils_nextflow_pipeline'
include { SAMPLESHEET_TO_CHANNEL  } from '../samplesheet_to_channel'

/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    SUBWORKFLOW TO INITIALISE PIPELINE
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

workflow PIPELINE_INITIALISATION {
    take:
    version // boolean: Display version and exit
    validate_params // boolean: Boolean whether to validate parameters against the schema at runtime
    monochrome_logs // boolean: Do not use coloured log outputs
    nextflow_cli_args //   array: List of positional nextflow CLI args
    outdir //  string: The output directory where the results will be saved
    input //  string: Path to input samplesheet
    help // boolean: Display help message and exit
    help_full // boolean: Show the full help message
    show_hidden // boolean: Show hidden parameters in the help message

    main:

    //
    // Print version and exit if required and dump pipeline parameters to JSON file
    UTILS_NEXTFLOW_PIPELINE(
        version,
        true,
        outdir,
        workflow.profile.tokenize(',').intersect(['conda', 'mamba']).size() >= 1,
    )

    // Validate parameters and generate parameter summary to stdout
    //

    def before_text = ""
    def after_text = ""
    before_text = """
-\033[2m----------------------------------------------------\033[0m-
                                        \033[0;32m,--.\033[0;30m/\033[0;32m,-.\033[0m
\033[0;34m        ___     __   __   __   ___     \033[0;32m/,-._.--~\'\033[0m
\033[0;34m  |\\ | |__  __ /  ` /  \\ |__) |__         \033[0;33m}  {\033[0m
\033[0;34m  | \\| |       \\__, \\__/ |  \\ |___     \033[0;32m\\`-._,-`-,\033[0m
                                        \033[0;32m`._,._,\'\033[0m
\033[0;37m      ____\033[0m
\033[0;37m    .´ _  `.\033[0m
\033[0;37m   /  \033[0;32m|\\\033[0m`-_ \\\033[0m     \033[0;34m __        __   ___     \033[0m
\033[0;37m  |   \033[0;32m| \\\033[0m  `-|\033[0m    \033[0;34m|__`  /\\  |__) |__  |__/\033[0m
\033[0;37m   \\ \033[0;32m|   \\\033[0m  /\033[0m     \033[0;34m.__| /¯¯\\ |  \\ |___ |  \\\033[0m
\033[0;37m    `\033[0;32m|\033[0m____\033[0;32m\\\033[0m´\033[0m

\033[0;35m  nf-core/sarek ${workflow.manifest.version}\033[0m
-\033[2m----------------------------------------------------\033[0m-
"""
    after_text = """${workflow.manifest.doi ? "\n* The pipeline\n" : ""}${workflow.manifest.doi.tokenize(",").collect { doi -> "    https://doi.org/${doi.trim().replace('https://doi.org/', '')}" }.join("\n")}${workflow.manifest.doi ? "\n" : ""}
* The nf-core framework
    https://doi.org/10.1038/s41587-020-0439-x

* Software dependencies
    https://github.com/nf-core/sarek/blob/master/CITATIONS.md
"""
    if (monochrome_logs) {
        before_text = before_text.replaceAll(/\033\[[0-9;]*m/, '')
    }

    command = "nextflow run ${workflow.manifest.name} -profile <docker/singularity/.../institute> --input samplesheet.csv --outdir <OUTDIR>"

    UTILS_NFSCHEMA_PLUGIN(
        workflow,
        validate_params,
        null,
        help,
        help_full,
        show_hidden,
        before_text,
        after_text,
        command,
        false,
    )

    // Check config provided to the pipeline
    UTILS_NFCORE_PIPELINE(nextflow_cli_args)

    // Custom validation for pipeline parameters
    validateInputParameters()

    // Check input path parameters to see if they exist
    def checkPathParamList = [
        params.ascat_alleles,
        params.ascat_loci,
        params.ascat_loci_gc,
        params.ascat_loci_rt,
        params.bwa,
        params.bwamem2,
        params.bcftools_annotations,
        params.bcftools_annotations_tbi,
        params.bcftools_columns,
        params.bcftools_header_lines,
        params.cf_chrom_len,
        params.chr_dir,
        params.cnvkit_reference,
        params.contamination_resource,
        params.contamination_resource_tbi,
        params.dbnsfp,
        params.dbnsfp_tbi,
        params.dbsnp,
        params.dbsnp_tbi,
        params.dict,
        params.dragmap,
        params.fasta,
        params.fasta_fai,
        params.force_call_alleles,
        params.force_call_alleles_tbi,
        params.germline_resource,
        params.germline_resource_tbi,
        params.input,
        params.intervals,
        params.known_indels,
        params.known_indels_tbi,
        params.known_snps,
        params.known_snps_tbi,
        params.mappability,
        params.multiqc_config,
        params.ngscheckmate_bed,
        params.pon,
        params.pon_tbi,
        params.sentieon_dnascope_model,
        params.spliceai_indel,
        params.spliceai_indel_tbi,
        params.spliceai_snv,
        params.spliceai_snv_tbi,
    ]

    // only check if we are using the tools
    if (params.tools && (params.tools.split(',').contains('snpeff') || params.tools.split(',').contains('merge'))) {
        checkPathParamList.add(params.snpeff_cache)
    }
    if (params.tools && (params.tools.split(',').contains('vep') || params.tools.split(',').contains('merge'))) {
        checkPathParamList.add(params.vep_cache)
    }

    params.input_restart = retrieveInput((!params.build_only_index && !input), params.step, params.outdir)

    ch_from_samplesheet = params.build_only_index
        ? channel.empty()
        : input
            ? channel.fromList(samplesheetToList(input, "${projectDir}/assets/schema_input.json"))
            : channel.fromList(samplesheetToList(params.input_restart, "${projectDir}/assets/schema_input.json"))

    SAMPLESHEET_TO_CHANNEL(
        ch_from_samplesheet,
        params.aligner,
        params.ascat_alleles,
        params.ascat_loci,
        params.ascat_loci_gc,
        params.ascat_loci_rt,
        params.bcftools_annotations,
        params.bcftools_annotations_tbi,
        params.bcftools_header_lines,
        params.build_only_index,
        params.contamination_resource,
        params.dbsnp,
        params.fasta,
        params.germline_resource,
        intervalsParam(),
        params.joint_germline,
        params.joint_mutect2,
        params.known_indels,
        params.known_snps,
        params.no_intervals,
        params.pon,
        params.sentieon_dnascope_emit_mode,
        params.sentieon_haplotyper_emit_mode,
        params.seq_center,
        params.seq_platform,
        params.skip_tools,
        params.snpeff_cache,
        params.snpeff_db,
        params.step,
        params.tools,
        params.umi_length,
        params.umi_location,
        params.umi_in_read_header,
        params.umi_read_structure,
        params.wes,
    )

    emit:
    samplesheet = SAMPLESHEET_TO_CHANNEL.out.input_sample
}

/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    SUBWORKFLOW FOR PIPELINE COMPLETION
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/

workflow PIPELINE_COMPLETION {
    take:
    email //  string: email address
    email_on_fail //  string: email address sent on pipeline failure
    plaintext_email // boolean: Send plain-text email instead of HTML
    outdir //    path: Path to output directory where results will be published
    monochrome_logs // boolean: Disable ANSI colour codes in log output
    multiqc_report //  string: Path to MultiQC report

    main:
    summary_params = paramsSummaryMap(workflow, parameters_schema: "nextflow_schema.json")
    def multiqc_reports = multiqc_report.toList()

    // Completion email and summary
    workflow.onComplete {
        if (email || email_on_fail) {
            completionEmail(
                summary_params,
                email,
                email_on_fail,
                plaintext_email,
                outdir,
                monochrome_logs,
                multiqc_reports.isBound() ? multiqc_reports.getVal() : [],
            )
        }

        completionSummary(monochrome_logs)
    }

    workflow.onError {
        log.error("Pipeline failed. Please refer to troubleshooting docs for common issues: https://nf-co.re/docs/running/troubleshooting")
    }
}

/*
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
    FUNCTIONS
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
*/
// Check and validate pipeline parameters
def validateInputParameters() {
    genomeExistsError()
    sparkAndBam()
    parabricksMutectcallerIgnoredParams()
    noIntervalsWithIntervals()
    intervalsMatchReference()
}

// Exit if --no_intervals would ignore a user-provided --intervals file
def noIntervalsWithIntervals() {
    // params.intervals is filled from the genome config by default
    def genome_intervals = params.genomes && params.genome ? params.genomes[params.genome]?.intervals : null
    if (params.no_intervals && intervalsParam() && params.intervals != genome_intervals) {
        error("`--intervals ${params.intervals}` and `--no_intervals` cannot be used together: `--no_intervals` would ignore the intervals file. Remove one of them.")
    }
}

// Intervals are checked at start-up (before any process runs) only for a user-provided FAI and a BED file,
// and only for steps that use intervals. Otherwise PREPARE_INTERVALS checks them once the FAI exists.
def intervalsChecked() {
    def intervals = intervalsParam()
    return !!(intervals && !params.no_intervals && params.fasta_fai && intervals.toLowerCase().endsWith('.bed') && !(params.step in ['annotate', 'controlfreec']))
}

// Fail before any process starts when --intervals does not fit a user-provided FAI
def intervalsMatchReference() {
    if (intervalsChecked()) {
        checkIntervalsWithinContigs(file(intervalsParam()), file(params.fasta_fai))
    }
}

// Fail if any BED interval is on a contig missing from the FAI or ends past its contig
def checkIntervalsWithinContigs(bed, fai) {
    def contig_length = [:]
    fai.eachLine { line ->
        def fields = line.split('\t')
        contig_length[fields[0]] = fields[1].toLong()
    }
    def unknown = [] as Set
    def past_end = []     // first 3 examples only
    def past_end_count = 0
    bed.eachLine { line ->
        if (line =~ /^(#|track|browser)/ || !line.trim()) return
        def fields = line.split('\t')
        if (fields.size() < 3 || !fields[2].isLong()) {
            error("--intervals: expected tab-separated columns contig, start, end (end must be a number), got: ${line}")
        }
        def (contig, start, end) = fields
        if (!contig_length.containsKey(contig)) {
            unknown << contig
        } else if (end.toLong() > contig_length[contig]) {
            past_end_count += 1
            if (past_end.size() < 3) {
                past_end << "${contig}:${start}-${end} (${contig} is ${contig_length[contig]} bp)"
            }
        }
    }
    if (unknown) {
        error("--intervals: contig(s) undefined in ${fai.name}: " + unknown.take(3).join(', '))
    }
    if (past_end_count) {
        error("--intervals: ${past_end_count} interval(s) end past their contig in the reference (${fai.name}), for example: " + past_end.join(', '))
    }
}

// `--intervals false` skips the genome intervals; Nextflow 26 passes it from the CLI as a string
def intervalsParam() {
    return params.intervals in [false, 'false'] ? null : params.intervals
}

// Exit pipeline if incorrect --genome key provided
def genomeExistsError() {
    if (params.genomes && params.genome && !params.genomes.containsKey(params.genome)) {
        def error_string = "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" + "  Genome '${params.genome}' not found in any config files provided to the pipeline.\n" + "  Currently, the available genome keys are:\n" + "  ${params.genomes.keySet().join(", ")}\n" + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        error(error_string)
    }
}

//  Exit if trying to use Spark markduplicates together with --save_mapped.
//  Spark markduplicates requires name-sorted input, so the mapped alignment is
//  produced name-sorted and cannot be indexed (or used downstream) regardless of
//  whether it is saved as BAM or CRAM.
def sparkAndBam() {
    if (params.use_gatk_spark && params.use_gatk_spark.contains('markduplicates') && params.save_mapped) {
        def error_string = "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n" + "  --use_gatk_spark with 'markduplicates' is not compatible with --save_mapped.\n" + "  Spark markduplicates requires name-sorted input, so the saved mapped\n" + "  alignment (BAM or CRAM) would be name-sorted and cannot be indexed.\n" + "  Either drop --save_mapped, or switch to the non-Spark markduplicates path.\n" + "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~"
        System.err.println(error_string)
        error(error_string)
    }
}

// Warn about options that the Parabricks mutectcaller path cannot honor
def parabricksMutectcallerIgnoredParams() {
    if (params.tools && params.tools.split(',').contains('parabricks_mutectcaller')) {
        if (params.joint_mutect2) {
            log.warn("`--joint_mutect2` is not supported by Parabricks mutectcaller and is ignored for `parabricks_mutectcaller`: samples are called per tumor-normal pair or per tumor-only sample.")
        }
        if (params.ignore_soft_clipped_bases) {
            log.warn("`--ignore_soft_clipped_bases` is not supported by Parabricks mutectcaller and is ignored for `parabricks_mutectcaller`: soft-clipped bases are used during calling.")
        }
    }
}

// Generate methods description for MultiQC
def toolCitationText() {
    // TODO nf-core: Optionally add in-text citation tools to this list.
    // Can use ternary operators to dynamically construct based conditions, e.g. params["run_xyz"] ? "Tool (Foo et al. 2023)" : "",
    // Uncomment function in methodsDescriptionText to render in MultiQC report
    def citation_text = [
        "Tools used in the workflow included:",
        "FastQC (Andrews 2010),",
        "MultiQC (Ewels et al. 2016)",
        ".",
    ].join(' ').trim()

    return citation_text
}

def toolBibliographyText() {
    // TODO nf-core: Optionally add bibliographic entries to this list.
    // Can use ternary operators to dynamically construct based conditions, e.g. params["run_xyz"] ? "<li>Author (2023) Pub name, Journal, DOI</li>" : "",
    // Uncomment function in methodsDescriptionText to render in MultiQC report
    def reference_text = [
        "<li>Andrews S, (2010) FastQC, URL: https://www.bioinformatics.babraham.ac.uk/projects/fastqc/).</li>",
        "<li>Ewels, P., Magnusson, M., Lundin, S., & Käller, M. (2016). MultiQC: summarize analysis results for multiple tools and samples in a single report. Bioinformatics , 32(19), 3047–3048. doi: /10.1093/bioinformatics/btw354</li>",
    ].join(' ').trim()

    return reference_text
}

def methodsDescriptionText(mqc_methods_yaml) {
    // Convert  to a named map so can be used as with familiar NXF ${workflow} variable syntax in the MultiQC YML file
    def meta = [:]
    meta.workflow = workflow.toMap()
    meta["manifest_map"] = workflow.manifest.toMap()

    // Pipeline DOI
    if (meta.manifest_map.doi) {
        // Using a loop to handle multiple DOIs
        // Removing `https://doi.org/` to handle pipelines using DOIs vs DOI resolvers
        // Removing ` ` since the manifest.doi is a string and not a proper list
        def temp_doi_ref = ""
        def manifest_doi = meta.manifest_map.doi.tokenize(",")
        manifest_doi.each { doi_ref ->
            temp_doi_ref += "(doi: <a href=\'https://doi.org/${doi_ref.replace("https://doi.org/", "").replace(" ", "")}\'>${doi_ref.replace("https://doi.org/", "").replace(" ", "")}</a>), "
        }
        meta["doi_text"] = temp_doi_ref.substring(0, temp_doi_ref.length() - 2)
    }
    else {
        meta["doi_text"] = ""
    }
    meta["nodoi_text"] = meta.manifest_map.doi ? "" : "<li>If available, make sure to update the text to include the Zenodo DOI of the pipeline version used. </li>"

    // Tool references
    meta["tool_citations"] = ""
    meta["tool_bibliography"] = ""

    // TODO nf-core: Only uncomment below if logic in toolCitationText/toolBibliographyText has been filled!
    // meta["tool_citations"] = toolCitationText().replaceAll(", \\.", ".").replaceAll("\\. \\.", ".").replaceAll(", \\.", ".")
    // meta["tool_bibliography"] = toolBibliographyText()


    def methods_text = mqc_methods_yaml.text

    def engine = new groovy.text.SimpleTemplateEngine()
    def description_html = engine.createTemplate(methods_text).make(meta)

    return description_html.toString()
}

// retrieveInput
def retrieveInput(need_input, step, outdir) {
    def input = null
    if (need_input) {
        if (step == 'mapping') {
            error("Can't start ${step} step without samplesheet")
        }
        else if (step == 'markduplicates') {
            log.warn("Using file ${outdir}/csv/mapped.csv")
            input = outdir + "/csv/mapped.csv"
        }
        else if (step == 'prepare_recalibration') {
            log.warn("Using file ${outdir}/csv/markduplicates_no_table.csv")
            input = outdir + "/csv/markduplicates_no_table.csv"
        }
        else if (step == 'recalibrate') {
            log.warn("Using file ${outdir}/csv/markduplicates.csv")
            input = outdir + "/csv/markduplicates.csv"
        }
        else if (step == 'variant_calling') {
            log.warn("Using file ${outdir}/csv/recalibrated.csv")
            input = outdir + "/csv/recalibrated.csv"
        }
        else if (step == 'annotate') {
            log.warn("Using file ${outdir}/csv/variantcalled.csv")
            input = outdir + "/csv/variantcalled.csv"
        }
        else {
            log.warn("Please provide an input samplesheet to the pipeline e.g. '--input samplesheet.csv'")
            error("Unknown step ${step}")
        }
    }
    return input
}
