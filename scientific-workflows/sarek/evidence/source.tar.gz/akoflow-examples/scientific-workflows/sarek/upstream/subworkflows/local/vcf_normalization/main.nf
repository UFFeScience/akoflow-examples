// Normalize all unannotated VCFs

// Import modules
include { ADD_INFO_TO_VCF                   } from '../../../modules/local/add_info_to_vcf'
include { BCFTOOLS_NORM as VCFS_NORM        } from '../../../modules/nf-core/bcftools/norm'
include { BCFTOOLS_SORT as VCFS_NORM_SORT   } from '../../../modules/nf-core/bcftools/sort'
include { HTSLIB_BGZIPTABIX as TABIX_EXT_VCF } from '../../../modules/nf-core/htslib/bgziptabix'

// Workflow to normalize, compress, and index VCF files
workflow NORMALIZE_VCFS {
    take:
    vcfs
    fasta

    main:
    // Add additional information to VCF files
    ADD_INFO_TO_VCF(vcfs)

    // Compress the VCF files with bgzip
    TABIX_EXT_VCF(ADD_INFO_TO_VCF.out.vcf.map{ meta, vcf -> [ meta, vcf, [], [] ] }, 'compress', true, 'vcf')

    // Normalize the VCF files with BCFTOOLS_NORM
    VCFS_NORM(TABIX_EXT_VCF.out.output.join(TABIX_EXT_VCF.out.index), fasta)

    // Sort the normalized VCF files
    VCFS_NORM_SORT(VCFS_NORM.out.vcf)

    emit:
    vcfs     = VCFS_NORM_SORT.out.vcf   // normalized vcfs
    tbis     = VCFS_NORM_SORT.out.index // matching tbis
}
