# SOMOSPIE soil-moisture inference

Scientific workflow adapted from TauferLab SOMOSPIE commit `55d317ea4d751d823086005dd5d8247e65dffd55`. The original BSD-3-Clause KNN/RF modeling functions and license are preserved unchanged in scripts/upstream. This publication describes the scientific workflow; execution environments are separate profiles.

## Real observation profile

A frozen Oklahoma crop [-99,35,-97,37], EPSG:4326, uses all 31 complete January 2010 ESA CCI COMBINED v07.1 daily global products and four complete Copernicus GLO-90 2021 surface tiles. The acquisition manifest records URLs, bytes and SHA256 for 35 objects (60,606,972 bytes). Acquisition downloads official sources directly; original source rasters are excluded from the public image, source package and derived results.

The workflow computes missing-aware monthly soil moisture on the native 0.25-degree grid, projects the surface to UTM14N at 90m for Horn slope/aspect and hillshade, and area-averages covariates onto observation/evaluation grids. The GLO-90 DSM includes vegetation and buildings, not bare-earth terrain. Its 2021 date differs explicitly from the 2010 moisture observations.

Unmodified upstream modeling routines perform a 10% holdout and full ten-fold searches: 50 KNN candidates (neighbors 2..19, original Gaussian/uniform/distance weights) and 10 random-forest candidates (original 300..2000 tree search). The adapter fixes split and RF estimator seeds to 3 and records actual CV results, scalers, indices and fitted models. Evaluation covers all 40,000 cells of a 0.01-degree grid. This geographic spacing is nominally about 1km and is not uniform metric resolution. Fine predictions are statistical inferences, not new independent observations. Seven held-out coarse cells cannot establish spatial or temporal generalization. Negative R2, if measured, is retained.

## Execution and visual results

Run `./prepare.sh`, `./validate.sh -definition`, then `./run.sh` and `./validate.sh`. Only acquisition requires outbound network. Twelve native activities produce georeferenced observed/predicted moisture maps and an actual held-out prediction diagnostic, plus derived tables, GeoTIFFs, trained models, full CV records and provenance. Publication of measured completion follows actual native execution and independent validation; a definition check alone does not demonstrate scientific completion.

## Sources and terms

- SOMOSPIE: https://github.com/TauferLab/SOMOSPIE
- ESA CCI v07.1 record: https://catalogue.ceda.ac.uk/uuid/c7e974411cfe4cf99cb077f7cb4d75d4/
- ESA scientific-use terms (no onward redistribution of original data): https://climate.esa.int/en/projects/soil-moisture/data/terms-and-conditions/
- ESA merging methodology: https://doi.org/10.5194/essd-11-717-2019
- Copernicus GLO-90, 2021 release: https://registry.opendata.aws/copernicus-dem/

Derived terrain products contain modified Copernicus DEM 2021 information. Original satellite products remain at their official providers. Public artifacts contain derived scientific results only. The obsolete original prepared-table Google Drive was unavailable; these tables are regenerated from real frozen observations, not synthetic data.

<!-- connected-hub-publication -->

## Measured daemon execution and Hub version

[Open the published workflow and measured results](http://192.168.1.13:3100/u/ovvesley/scientific-workflows-somospie). Run `somospie-local-8d06129260-run-20261115t205251.196217106` completed **12/12 activities** in **127.084 seconds**. These are observed Docker computations. The imported manual plan contains placeholder predicted timings and is not a benchmark.

Configured Hub origin: `http://192.168.1.13:3100`. This receipt applies to that instance. The OCI image must be built from this bundle on the execution host; public registry availability is not claimed.

Import URI for this configured Hub:

```text
akoflow://hub/publications/2dbd491f-d1b0-49b2-8b95-74cd8a3a2d11/versions/1
```
