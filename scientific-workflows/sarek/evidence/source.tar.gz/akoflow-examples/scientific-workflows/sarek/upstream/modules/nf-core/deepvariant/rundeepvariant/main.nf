process DEEPVARIANT_RUNDEEPVARIANT {
    tag "${meta.id}"
    label 'process_high'

    // FIXME Conda is not supported at the moment
    // https://github.com/bioconda/bioconda-recipes/pull/45214#issuecomment-1890937836
    // BUG https://github.com/nf-core/modules/issues/1754
    // BUG https://github.com/bioconda/bioconda-recipes/issues/30310
    container "docker.io/google/deepvariant:1.10.0"

    input:
    tuple val(meta), path(input), path(index), path(intervals)
    tuple val(meta2), path(fasta)
    tuple val(meta3), path(fai)
    tuple val(meta4), path(gzi)
    tuple val(meta5), path(par_bed)

    output:
    tuple val(meta), path("${prefix}.vcf.gz")            , emit: vcf
    tuple val(meta), path("${prefix}.vcf.gz.{tbi,csi}")  , emit: vcf_index
    tuple val(meta), path("${prefix}.g.vcf.gz")          , emit: gvcf
    tuple val(meta), path("${prefix}.g.vcf.gz.{tbi,csi}"), emit: gvcf_index
    tuple val(meta), path("${prefix}.visual_report.html"), emit: report, optional: true
    tuple val("${task.process}"), val('deepvariant'), eval("/opt/deepvariant/bin/run_deepvariant --version | sed 's/^.*version //'"), topic: versions, emit: versions_deepvariant

    when:
    task.ext.when == null || task.ext.when

    script:
    // Exit if running this module with -profile conda / -profile mamba
    if (workflow.profile.tokenize(',').intersect(['conda', 'mamba']).size() >= 1) {
        error("DEEPVARIANT module does not support Conda. Please use Docker / Singularity / Podman instead.")
    }
    def args = task.ext.args ?: ''
    prefix = task.ext.prefix ?: "${meta.id}"
    def regions = intervals ? "--regions=${intervals}" : ""
    def par_regions = par_bed ? "--par_regions_bed=${par_bed}" : ""

    """
    export MPLCONFIGDIR=\$PWD/.matplotlib
    mkdir -p \$MPLCONFIGDIR

    /opt/deepvariant/bin/run_deepvariant \\
        --ref=${fasta} \\
        --reads=${input} \\
        --output_vcf=${prefix}.vcf.gz \\
        --output_gvcf=${prefix}.g.vcf.gz \\
        ${args} \\
        ${regions} \\
        ${par_regions} \\
        --intermediate_results_dir=tmp \\
        --num_shards=${task.cpus}
    """

    stub:
    // Exit if running this module with -profile conda / -profile mamba
    if (workflow.profile.tokenize(',').intersect(['conda', 'mamba']).size() >= 1) {
        error("DEEPVARIANT module does not support Conda. Please use Docker / Singularity / Podman instead.")
    }
    prefix = task.ext.prefix ?: "${meta.id}"
    """
    echo "stub" | gzip > ${prefix}.vcf.gz
    echo "stub" | gzip > ${prefix}.vcf.gz.tbi
    echo "stub" | gzip > ${prefix}.g.vcf.gz
    echo "stub" | gzip > ${prefix}.g.vcf.gz.tbi
    """
}
