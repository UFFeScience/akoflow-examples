process DRAGMAP_HASHTABLE {
    tag "${fasta}"
    label 'process_high'

    conda "${moduleDir}/environment.yml"
    // WARN: Do not update this tool to 1.3.0 until https://github.com/Illumina/DRAGMAP/issues/47 is resolved
    container "${workflow.containerEngine in ['singularity', 'apptainer'] && !task.ext.singularity_pull_docker_container
        ? 'https://depot.galaxyproject.org/singularity/dragmap:1.2.1--h72d16da_1'
        : 'quay.io/biocontainers/dragmap:1.2.1--h72d16da_1'}"

    input:
    tuple val(meta), path(fasta)

    output:
    tuple val(meta), path("dragmap"), emit: hashmap
    tuple val("${task.process}"), val('dragmap'), eval("dragen-os --version 2>&1"), emit: versions_dragmap, topic: versions

    when:
    task.ext.when == null || task.ext.when

    script:
    def args = task.ext.args ?: ''
    """
    mkdir dragmap
    dragen-os \\
        --build-hash-table true \\
        --ht-reference ${fasta} \\
        --output-directory dragmap \\
        ${args} \\
        --ht-num-threads ${task.cpus}
    """

    stub:
    """
    mkdir dragmap
    """
}
