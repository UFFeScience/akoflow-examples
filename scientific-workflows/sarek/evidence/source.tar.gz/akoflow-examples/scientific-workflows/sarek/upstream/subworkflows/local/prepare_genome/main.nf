include { BBMAP_BBSPLIT as BBMAP_INDEX              } from '../../../modules/nf-core/bbmap/bbsplit'
include { BWAMEM2_INDEX                             } from '../../../modules/nf-core/bwamem2/index'
include { BWA_INDEX as BWAMEM1_INDEX                } from '../../../modules/nf-core/bwa/index'
include { DRAGMAP_HASHTABLE                         } from '../../../modules/nf-core/dragmap/hashtable'
include { GATK4_CREATESEQUENCEDICTIONARY            } from '../../../modules/nf-core/gatk4/createsequencedictionary'
include { MSISENSORPRO_SCAN                         } from '../../../modules/nf-core/msisensorpro/scan'
include { SAMTOOLS_FAIDX                            } from '../../../modules/nf-core/samtools/faidx'
include { HTSLIB_BGZIPTABIX as TABIX_BCFTOOLS_ANNOTATIONS } from '../../../modules/nf-core/htslib/bgziptabix'
include { HTSLIB_BGZIPTABIX as TABIX_CONTAMINATION_RESOURCE } from '../../../modules/nf-core/htslib/bgziptabix'
include { HTSLIB_BGZIPTABIX as TABIX_DBSNP                } from '../../../modules/nf-core/htslib/bgziptabix'
include { HTSLIB_BGZIPTABIX as TABIX_GERMLINE_RESOURCE    } from '../../../modules/nf-core/htslib/bgziptabix'
include { HTSLIB_BGZIPTABIX as TABIX_KNOWN_INDELS         } from '../../../modules/nf-core/htslib/bgziptabix'
include { HTSLIB_BGZIPTABIX as TABIX_KNOWN_SNPS           } from '../../../modules/nf-core/htslib/bgziptabix'
include { HTSLIB_BGZIPTABIX as TABIX_FORCE_CALL_ALLELES   } from '../../../modules/nf-core/htslib/bgziptabix'
include { HTSLIB_BGZIPTABIX as TABIX_PON                  } from '../../../modules/nf-core/htslib/bgziptabix'
include { UNTAR as UNTAR_BBSPLIT_INDEX              } from '../../../modules/nf-core/untar'
include { UNTAR as UNTAR_CHR_DIR                    } from '../../../modules/nf-core/untar'
include { UNTAR as UNTAR_MSISENSOR2_MODELS          } from '../../../modules/nf-core/untar'
include { UNZIP as UNZIP_ALLELES                    } from '../../../modules/nf-core/unzip'
include { UNZIP as UNZIP_GC                         } from '../../../modules/nf-core/unzip'
include { UNZIP as UNZIP_LOCI                       } from '../../../modules/nf-core/unzip'
include { UNZIP as UNZIP_RT                         } from '../../../modules/nf-core/unzip'

workflow PREPARE_GENOME {
    take:
    ascat_alleles_in              // params.ascat_alleles
    ascat_loci_in                 // params.ascat_loci
    ascat_loci_gc_in              // params.ascat_loci_gc
    ascat_loci_rt_in              // params.ascat_loci_rt
    bbsplit_fasta_list_in         // params.bbsplit_fasta_list
    bbsplit_index_in              // params.bbsplit_index
    bcftools_annotations_in       // params.bcftools_annotations
    bcftools_annotations_tbi_in   // params.bcftools_annotations
    bwa_in                        // params.bwa
    bwamem2_in                    // params.bwamem2
    chr_dir_in                    // params.chr_dir
    contamination_resource_in     // params.contamination_resource
    contamination_resource_tbi_in // params.contamination_resource_tbi
    dbsnp_in                      // params.dbsnp
    dbsnp_tbi_in                  // params.dbsnp_tbi
    dict_in                       // params.dict
    dragmap_in                    // params.dragmap
    fasta_in                      // params.fasta
    fasta_fai_in                  // params.fasta_fai
    force_call_alleles_in         // params.force_call_alleles
    force_call_alleles_tbi_in     // params.force_call_alleles_tbi
    germline_resource_in          // params.germline_resource
    germline_resource_tbi_in      // params.germline_resource_tbi
    known_indels_in               // params.known_indels
    known_indels_tbi_in           // params.known_indels_tbi
    known_snps_in                 // params.known_snps
    known_snps_tbi_in             // params.known_snps_tbi
    msisensor2_models_in          // channel: [optional]  msisensor2_models
    msisensorpro_scan_in          // channel: [optional]  msisensorpro_scan
    pon_in                        // params.pon
    pon_tbi_in                    // params.pon_tbi
    aligner                       // params.aligner
    step                          // params.step
    tools                         // params.tools
    vep_include_fasta             // params.vep_include_fasta

    main:
    // TODO: EXTRACT FASTA FILE?
    fasta = fasta_in ? channel.fromPath(fasta_in).map { fasta -> [[id: fasta.baseName], fasta] }.collect() : channel.empty()
    vep_fasta = vep_include_fasta ? fasta : [[id: 'null'], []]

    if (step == 'mapping') {
        if (!bwa_in && (aligner == "bwa-mem" || aligner == "sentieon-bwamem" || aligner == "parabricks")) {
            BWAMEM1_INDEX(fasta)
            index_alignment = BWAMEM1_INDEX.out.index.collect()
        }
        else if (aligner == "bwa-mem" || aligner == "sentieon-bwamem" || aligner == "parabricks") {
            index_alignment = channel.fromPath(bwa_in).map { index -> [[id: 'bwa'], index] }.collect()
        }
        else if (!bwamem2_in && aligner == 'bwa-mem2') {
            BWAMEM2_INDEX(fasta)
            index_alignment = BWAMEM2_INDEX.out.index.collect()
        }
        else if (aligner == 'bwa-mem2') {
            index_alignment = channel.fromPath(bwamem2_in).map { index -> [[id: 'bwamem2'], index] }.collect()
        }
        else if (!dragmap_in && aligner == 'dragmap') {
            DRAGMAP_HASHTABLE(fasta)
            index_alignment = DRAGMAP_HASHTABLE.out.hashmap.collect()
        }
        else if (aligner == 'dragmap') {
            index_alignment = channel.fromPath(dragmap_in).map { index -> [[id: 'dragmap'], index] }.collect()
        }
    }
    else {
        index_alignment = channel.empty()
    }

    if (!dict_in && step != "annotate") {
        GATK4_CREATESEQUENCEDICTIONARY(fasta)
        dict = GATK4_CREATESEQUENCEDICTIONARY.out.dict.collect()
    }
    else if (dict_in) {
        dict = channel.fromPath(dict_in).map { dict_ -> [[id: 'dict'], dict_] }.collect()
    }
    else {
        dict = channel.empty()
    }

    if (!fasta_fai_in && step != "annotate") {
        SAMTOOLS_FAIDX(fasta.map { meta, fasta_ -> [ meta, fasta_, [] ] }, false)
        fasta_fai = SAMTOOLS_FAIDX.out.fai.collect()
    }
    else if (fasta_fai_in) {
        fasta_fai = channel.fromPath(fasta_fai_in).map { fai -> [[id: 'fai'], fai] }.collect()
    }
    else {
        fasta_fai = channel.empty()
    }

    // Prepare genome for BBSplit contamination filtering
    bbsplit_index = channel.empty()
    if (tools && tools.split(',').contains('bbsplit')) {
        if (bbsplit_index_in) {
            // Use user-provided bbsplit index
            if (bbsplit_index_in.endsWith('.tar.gz')) {
                bbsplit_index = UNTAR_BBSPLIT_INDEX([[id: 'bbsplit_index'], file(bbsplit_index_in, checkIfExists: true)]).untar.map { _meta, index -> index }
            }
            else {
                bbsplit_index = channel.value(file(bbsplit_index_in, checkIfExists: true))
            }
        }
        else if (bbsplit_fasta_list_in) {
            // Build it from scratch if we have FASTA
            ch_bbsplit_fasta_list = channel.of(file(bbsplit_fasta_list_in, checkIfExists: true))
                .splitCsv(header: false, sep: ',')
                .flatMap { id, fafile -> [['id', id], ['fasta', file(fafile, checkIfExists: true)]] }
                .groupTuple()
                .map { group -> group[1] }
                .collect { fasta_group -> [fasta_group] }

            bbsplit_index = BBMAP_INDEX(
                [[id: "build_index"], []],
                [],
                fasta.map { _meta, fasta_ -> fasta_ },
                ch_bbsplit_fasta_list,
                true,
            ).index
        }
    }

    bcftools_annotations = bcftools_annotations_in ? channel.fromPath(bcftools_annotations_in).collect() : channel.value([])
    bcftools_annotations_tbi = bcftools_annotations_tbi_in ? channel.fromPath(bcftools_annotations_tbi_in).collect() : channel.value([])

    if (!bcftools_annotations_tbi_in && bcftools_annotations_in) {
        TABIX_BCFTOOLS_ANNOTATIONS(bcftools_annotations.flatten().map { vcf -> [[id: vcf.baseName], vcf, [], []] }, 'compress', true, '')
        bcftools_annotations_tbi = TABIX_BCFTOOLS_ANNOTATIONS.out.index.map { _meta, tbi -> [tbi] }.collect()

    }

    dbsnp = dbsnp_in ? channel.fromPath(dbsnp_in).collect() : channel.value([])
    dbsnp_tbi = dbsnp_tbi_in ? channel.fromPath(dbsnp_tbi_in).collect() : channel.value([])

    if (!dbsnp_tbi_in && dbsnp_in && ((step == "mapping" || step == "markduplicates" || step == "prepare_recalibration") || (tools.split(',').contains('controlfreec') || tools.split(',').contains('haplotypecaller') || tools.split(',').contains('sentieon_haplotyper') || tools.split(',').contains('sentieon_dnascope') || tools.split(',').contains('muse') || tools.split(',').contains('mutect2')))) {
        TABIX_DBSNP(dbsnp.flatten().map { vcf -> [[id: vcf.baseName], vcf, [], []] }, 'compress', true, '')
        dbsnp_tbi = TABIX_DBSNP.out.index.map { _meta, tbi -> [tbi] }.collect()
    }

    // Mutect2 and Parabricks MutectCaller need the same indexed resources
    def run_mutect2 = tools.split(',').contains('mutect2') || tools.split(',').contains('parabricks_mutectcaller')

    germline_resource = germline_resource_in ? channel.fromPath(germline_resource_in).collect() : channel.value([])
    germline_resource_tbi = germline_resource_tbi_in ? channel.fromPath(germline_resource_tbi_in).collect() : channel.value([])

    if (!germline_resource_tbi_in && germline_resource_in && (run_mutect2 || tools.split(',').contains('sentieon_tnscope'))) {
        TABIX_GERMLINE_RESOURCE(germline_resource.flatten().map { vcf -> [[id: vcf.baseName], vcf, [], []] }, 'compress', true, '')
        germline_resource_tbi = TABIX_GERMLINE_RESOURCE.out.index.map { _meta, tbi -> [tbi] }.collect()
    }

    // GetPileupSummaries falls back to the germline resource, which can be much larger than a set of common SNPs
    contamination_resource = contamination_resource_in ? channel.fromPath(contamination_resource_in).collect() : germline_resource
    contamination_resource_tbi = contamination_resource_in ? (contamination_resource_tbi_in ? channel.fromPath(contamination_resource_tbi_in).collect() : channel.value([])) : germline_resource_tbi

    if (contamination_resource_in && !contamination_resource_tbi_in && run_mutect2) {
        TABIX_CONTAMINATION_RESOURCE(contamination_resource.flatten().map { vcf -> [[id: vcf.baseName], vcf, [], []] }, 'compress', true, '')
        contamination_resource_tbi = TABIX_CONTAMINATION_RESOURCE.out.index.map { _meta, tbi -> [tbi] }.collect()
    }

    known_indels = known_indels_in ? channel.fromPath(known_indels_in).collect() : channel.value([])
    known_indels_tbi = known_indels_tbi_in ? channel.fromPath(known_indels_tbi_in).collect() : channel.value([])

    if (!known_indels_tbi_in && known_indels_in && (step == 'mapping' || step == "markduplicates" || step == 'prepare_recalibration' || (tools.split(',').contains('haplotypecaller') || tools.split(',').contains('sentieon_haplotyper') || tools.split(',').contains('sentieon_dnascope')))) {
        TABIX_KNOWN_INDELS(known_indels.flatten().map { vcf -> [[id: vcf.baseName], vcf, [], []] }, 'compress', true, '')
        known_indels_tbi = TABIX_KNOWN_INDELS.out.index.map { _meta, tbi -> [tbi] }.collect()
    }

    known_snps = known_snps_in ? channel.fromPath(known_snps_in).collect() : channel.value([])
    known_snps_tbi = known_snps_tbi_in ? channel.fromPath(known_snps_tbi_in).collect() : channel.value([])

    if (!known_snps_tbi_in && known_snps_in && (step == 'mapping' || step == "markduplicates" || step == 'prepare_recalibration' || (tools.split(',').contains('haplotypecaller') || tools.split(',').contains('sentieon_haplotyper')))) {
        TABIX_KNOWN_SNPS(known_snps.flatten().map { vcf -> [[id: vcf.baseName], vcf, [], []] }, 'compress', true, '')
        known_snps_tbi = TABIX_KNOWN_SNPS.out.index.map { _meta, tbi -> [tbi] }.collect()
    }

    force_call_alleles = force_call_alleles_in ? channel.fromPath(force_call_alleles_in).collect() : channel.value([])
    force_call_alleles_tbi = force_call_alleles_tbi_in ? channel.fromPath(force_call_alleles_tbi_in).collect() : channel.value([])

    if (!force_call_alleles_tbi_in && force_call_alleles_in && run_mutect2) {
        TABIX_FORCE_CALL_ALLELES(force_call_alleles.flatten().map { vcf -> [[id: vcf.baseName], vcf, [], []] }, 'compress', true, '')
        force_call_alleles_tbi = TABIX_FORCE_CALL_ALLELES.out.index.map { _meta, tbi -> [tbi] }.collect()
    }

    pon = pon_in ? channel.fromPath(pon_in).collect() : channel.value([])
    pon_tbi = pon_tbi_in ? channel.fromPath(pon_tbi_in).collect() : channel.value([])

    if (!pon_tbi_in && pon_in && run_mutect2) {
        TABIX_PON(pon.flatten().map { vcf -> [[id: vcf.baseName], vcf, [], []] }, 'compress', true, '')
        pon_tbi = TABIX_PON.out.index.map { _meta, tbi -> [tbi] }.collect()
    }

    // known_sites is made by grouping both the dbsnp and the known snps/indels resources
    // Which can either or both be optional
    known_sites_indels = dbsnp.concat(known_indels).collect()
    known_sites_indels_tbi = dbsnp_tbi.concat(known_indels_tbi).collect()
    known_sites_snps = dbsnp.concat(known_snps).collect()
    known_sites_snps_tbi = dbsnp_tbi.concat(known_snps_tbi).collect()

    // MSI
    if (msisensor2_models_in && msisensor2_models_in.endsWith(".tar.gz") && tools.split(',').contains('msisensor2')) {
        UNTAR_MSISENSOR2_MODELS(channel.fromPath(file(msisensor2_models_in)).map { archive -> [[id: archive.baseName], archive] })
        msisensor2_models = UNTAR_MSISENSOR2_MODELS.out.untar.collect()
    }
    else if (msisensor2_models_in && tools.split(',').contains('msisensor2')) {
        msisensor2_models = channel.fromPath(msisensor2_models_in).map { model -> [[id:model.baseName], model] }.collect()
    }
    else {
        msisensor2_models = channel.value([])
    }

    if (msisensorpro_scan_in) {
        msisensorpro_scan = channel.fromPath(msisensorpro_scan_in).collect()
    }
    else if (tools.split(',').contains('msisensorpro')) {
        MSISENSORPRO_SCAN(fasta)
        msisensorpro_scan = MSISENSORPRO_SCAN.out.list.map { _meta, list -> [list] }.collect()
    }
    else {
        msisensorpro_scan = channel.value([])
    }

    // prepare ascat and controlfreec reference files
    if (!ascat_alleles_in) {
        ascat_alleles = channel.empty()
    }
    else if (ascat_alleles_in.endsWith(".zip") && tools.split(',').contains('ascat')) {
        UNZIP_ALLELES(channel.fromPath(file(ascat_alleles_in)).map { archive -> [[id: archive.baseName], archive] })
        ascat_alleles = UNZIP_ALLELES.out.unzipped_archive.map { _meta, extracted_archive -> extracted_archive }.collect()
    }
    else {
        ascat_alleles = channel.fromPath(ascat_alleles_in).collect()
    }

    if (!ascat_loci_in) {
        ascat_loci = channel.empty()
    }
    else if (ascat_loci_in.endsWith(".zip") && tools.split(',').contains('ascat')) {
        UNZIP_LOCI(channel.fromPath(file(ascat_loci_in)).map { archive -> [[id: archive.baseName], archive] })
        ascat_loci = UNZIP_LOCI.out.unzipped_archive.map { _meta, extracted_archive -> extracted_archive }.collect()
    }
    else {
        ascat_loci = channel.fromPath(ascat_loci_in).collect()
    }

    if (!ascat_loci_gc_in) {
        ascat_loci_gc = channel.value([])
    }
    else if (ascat_loci_gc_in.endsWith(".zip") && tools.split(',').contains('ascat')) {
        UNZIP_GC(channel.fromPath(file(ascat_loci_gc_in)).map { archive -> [[id: archive.baseName], archive] })
        ascat_loci_gc = UNZIP_GC.out.unzipped_archive.map { _meta, extracted_archive -> extracted_archive }.collect()
    }
    else {
        ascat_loci_gc = channel.fromPath(ascat_loci_gc_in).collect()
    }

    if (!ascat_loci_rt_in) {
        ascat_loci_rt = channel.value([])
    }
    else if (ascat_loci_rt_in.endsWith(".zip") && tools.split(',').contains('ascat')) {
        UNZIP_RT(channel.fromPath(file(ascat_loci_rt_in)).map { archive -> [[id: archive.baseName], archive] })
        ascat_loci_rt = UNZIP_RT.out.unzipped_archive.map { _meta, extracted_archive -> extracted_archive }.collect()
    }
    else {
        ascat_loci_rt = channel.fromPath(ascat_loci_rt_in).collect()
    }

    if (!chr_dir_in) {
        chr_dir = channel.value([])
    }
    else if (chr_dir_in.endsWith(".tar.gz") && tools.split(',').contains('controlfreec')) {
        UNTAR_CHR_DIR(channel.fromPath(file(chr_dir_in)).map { archive -> [[id: archive.baseName], archive] })
        chr_dir = UNTAR_CHR_DIR.out.untar.map { _meta, extracted_archive -> extracted_archive }.collect()
    }
    else {
        chr_dir = channel.fromPath(chr_dir_in).collect()
    }

    emit:
    ascat_alleles              // Channel: [ascat_alleles]
    ascat_loci                 // Channel: [ascat_loci]
    ascat_loci_gc              // Channel: [ascat_loci_gc]
    ascat_loci_rt              // Channel: [ascat_loci_rt]
    bbsplit_index              // Channel: [bbsplit/index/]
    bcftools_annotations       // Channel: [bcftools_annotations]
    bcftools_annotations_tbi   // Channel: [bcftools_annotations_tbi]
    chr_dir                    // Channel: [chr_dir/]
    contamination_resource     // Channel: [contamination_resource], germline_resource if not provided
    contamination_resource_tbi // Channel: [contamination_resource_tbi]
    dbsnp                      // Channel: [dbsnp]
    dbsnp_tbi                  // Channel: [dbsnp_tbi]
    dict                       // Channel: [meta, dict]
    fasta                      // Channel: [meta, fasta]
    fasta_fai                  // Channel: [meta, fasta_fai]
    force_call_alleles         // Channel: [force_call_alleles]
    force_call_alleles_tbi     // Channel: [force_call_alleles_tbi]
    germline_resource          // Channel: [germline_resource]
    germline_resource_tbi      // Channel: [germline_resource_tbi]
    index_alignment            // Channel: [meta, index_alignment/] either bwa/, bwamem2/ or dragmap/
    known_indels               // Channel: [known_indels]
    known_indels_tbi           // Channel: [known_indels_tbi]
    known_sites_indels         // Channel: [known_sites_indels]
    known_sites_indels_tbi     // Channel: [known_sites_indels_tbi]
    known_sites_snps           // Channel: [known_sites_snps]
    known_sites_snps_tbi       // Channel: [known_sites_snps_tbi]
    known_snps                 // Channel: [known_snps]
    known_snps_tbi             // Channel: [known_snps_tbi]
    msisensor2_models          // Channel: [models/]
    msisensorpro_scan          // Channel: [genome_msi.list]
    pon                        // Channel: [pon]
    pon_tbi                    // Channel: [pon_tbi]
    vep_fasta                  // Channel: [meta, vep_fasta]
}
