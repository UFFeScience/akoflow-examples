process FREEBAYES {
    tag "${meta.id}"
    label 'process_single'

    conda "${moduleDir}/environment.yml"
    container "${workflow.containerEngine in ['singularity', 'apptainer'] && !task.ext.singularity_pull_docker_container
        ? 'https://depot.galaxyproject.org/singularity/freebayes:1.3.10--hbefcdb2_0'
        : 'quay.io/biocontainers/freebayes:1.3.10--hbefcdb2_0'}"

    input:
    tuple val(meta), path(input_1), path(input_1_index), path(input_2), path(input_2_index), path(target_bed)
    tuple val(meta2), path(fasta)
    tuple val(meta3), path(fasta_fai)
    tuple val(meta4), path(samples)
    tuple val(meta5), path(populations)
    tuple val(meta6), path(cnv)

    output:
    tuple val(meta), path("*.vcf.gz"), emit: vcf
    tuple val("${task.process}"), val('freebayes'), eval('freebayes --version 2>&1 | sed "s/version:\s*v//g"'), emit: versions_freebayes, topic: versions


    when:
    task.ext.when == null || task.ext.when

    script:
    def args    = task.ext.args   ?: ''
    def prefix  = task.ext.prefix ?: "${meta.id}"
    def input            = input_2     ? "${input_1} ${input_2}"        : "${input_1}"
    def targets_file     = target_bed  ? "--target ${target_bed}"       : ""
    def samples_file     = samples     ? "--samples ${samples}"         : ""
    def populations_file = populations ? "--populations ${populations}" : ""
    def cnv_file         = cnv         ? "--cnv-map ${cnv}"             : ""
    """
    freebayes \\
        -f ${fasta} \\
        ${targets_file} \\
        ${samples_file} \\
        ${populations_file} \\
        ${cnv_file} \\
        ${args} \\
        ${input} > ${prefix}.vcf

    bgzip ${prefix}.vcf
    """

    stub:
    def prefix = task.ext.prefix ?: "${meta.id}"
    """
    echo "" | gzip > ${prefix}.vcf.gz
    """
}
